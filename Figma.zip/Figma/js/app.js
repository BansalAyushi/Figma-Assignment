function myFunction() {
	document.getElementById("myDropdown").classList.toggle("show");
  }
  
  // Close the dropdown if the user clicks outside of it
  window.onclick = function(event) {
	if (!event.target.matches('.dropbtn')) {
	  var dropdowns = document.getElementsByClassName("dropdown-content");
	  var i;
	  for (i = 0; i < dropdowns.length; i++) {
		var openDropdown = dropdowns[i];
		if (openDropdown.classList.contains('show')) {
		  openDropdown.classList.remove('show');
		}
	  }
	}
  }

  function myFunction1() {
	document.getElementById("myDropdown1").classList.toggle("show");
  }
  
  // Close the dropdown if the user clicks outside of it
  window.onclick = function(event) {
	if (!event.target.matches('.dropbtn')) {
	  var dropdowns = document.getElementsByClassName("dropdown-content");
	  var i;
	  for (i = 0; i < dropdowns.length; i++) {
		var openDropdown = dropdowns[i];
		if (openDropdown.classList.contains('show')) {
		  openDropdown.classList.remove('show');
		}
	  }
	}
  }
  window.addEventListener('mouseup',function(event){
	var id01 = document.getElementById('id01');
		id01.style.display = 'none';
});  
 
  var last_zoom_value_page2 = 0.06;
  var last_zoom_value_page1 = 0.2;


function myZoom_in()
{
	var new_zoom_value_page2 = last_zoom_value_page2*2;
	document.getElementById("main_page").style.transform = "scale(" + new_zoom_value_page2 + ")";
	last_zoom_value_page2 = new_zoom_value_page2;
	document.getElementById("label_zoom").innerHTML = new_zoom_value_page2*100+ "%";
}

function myZoom_out()
{

	var new_zoom_value_page2 = last_zoom_value_page2-0.01;
	document.getElementById("main_page").style.transform = "scale(" + new_zoom_value_page2 + ")";
	last_zoom_value_page2 = new_zoom_value_page2;
	document.getElementById("label_zoom").innerHTML = (new_zoom_value_page2*100).toFixed(2)+ "%";

}

function myZoom_in1()
{
	var new_zoom_value_page1 = last_zoom_value_page1*2;
	document.getElementById("main_page").style.transform = "scale(" + new_zoom_value_page1 + ")";
	last_zoom_value_page1 = new_zoom_value_page1;
	document.getElementById("label_zoom").innerHTML = new_zoom_value_page1*100+ "%";

}

function myZoom_out1()
{

	var new_zoom_value_page1 = last_zoom_value_page1-0.01;
	document.getElementById("main_page").style.transform = "scale(" + new_zoom_value_page1 + ")";
	last_zoom_value_page1 = new_zoom_value_page1;
	document.getElementById("label_zoom").innerHTML = new_zoom_value_page1*100+ "%";

}


function myZoom_tofit()
{
	document.getElementById("main_page").style.transform = "scale(0.06)";
	document.getElementById("label_zoom").innerHTML = "6%";

}

function myZoom_tofit1()
{
	document.getElementById("main_page").style.transform = "scale(0.2)";
	document.getElementById("label_zoom").innerHTML = "21%";


}

function myZoom_to50()
{
	document.getElementById("main_page").style.transform = "scale(0.5)";
	document.getElementById("label_zoom").innerHTML = "50%";


}

function myZoom_to100()
{
	document.getElementById("main_page").style.transform = "scale(1)";
	document.getElementById("label_zoom").innerHTML = "100%";


}
function myZoom_to200()
{
	document.getElementById("main_page").style.transform = "scale(2)";
	document.getElementById("label_zoom").innerHTML = "200%";


}

function pixel_grid()
{
if(document.getElementById("check1").style.display == "none")
{
	document.getElementById("myPopup").innerHTML = "Pixel Grid Visible";

	document.getElementById("myPopup").style.display = "block";
	document.getElementById("check1").style.display = "block";
document.getElementById("pixel_grid").style.marginTop = "-21px";

}

else
{
	document.getElementById("myPopup").style.display = "block";

	document.getElementById("myPopup").innerHTML = "Pixel Grid Hidden";
	document.getElementById("check1").style.display = "none";
	document.getElementById("pixel_grid").style.marginTop = "0px";
	
}
}

function snap_grid()
{
if(document.getElementById("check2").style.display == "none")
{
document.getElementById("myPopup").innerHTML = "Snap to Pixel Grid Enabled";

document.getElementById("myPopup").style.display = "block";

document.getElementById("check2").style.display = "block";
document.getElementById("snap_grid").style.marginTop = "-21px";

}

else
{
	document.getElementById("myPopup").innerHTML = "Snap to Pixel Grid Disabled";

document.getElementById("myPopup").style.display = "block";

	document.getElementById("check2").style.display = "none";
	document.getElementById("snap_grid").style.marginTop = "0px";
	
}
}

function layout_grid()
{
if(document.getElementById("check3").style.display == "none")
{
document.getElementById("myPopup").innerHTML = "Layout Grid Visible";

document.getElementById("myPopup").style.display = "block";

document.getElementById("check3").style.display = "block";
document.getElementById("layout_grid").style.marginTop = "-21px";

}

else
{
	document.getElementById("myPopup").innerHTML = "Layout Grid Hidden";

document.getElementById("myPopup").style.display = "block";

	document.getElementById("check3").style.display = "none";
	document.getElementById("layout_grid").style.marginTop = "0px";
	
}
}

function outlines()
{
if(document.getElementById("check5").style.display == "none")
{
document.getElementById("myPopup").innerHTML = "Outlines Visible";

document.getElementById("myPopup").style.display = "block";

document.getElementById("check5").style.display = "block";
document.getElementById("outlines").style.marginTop = "-21px";

}

else
{
	document.getElementById("myPopup").innerHTML = "Outlines Hidden";

document.getElementById("myPopup").style.display = "block";

	document.getElementById("check5").style.display = "none";
	document.getElementById("outlines").style.marginTop = "0px";
	
}
}

function cursor()
{
if(document.getElementById("check6").style.display == "none")
{
document.getElementById("myPopup").innerHTML = "Multiplayer Cursors Visible";

document.getElementById("myPopup").style.display = "block";

document.getElementById("check6").style.display = "block";
document.getElementById("cursor").style.marginTop = "-21px";

}

else
{
	document.getElementById("myPopup").innerHTML = "Multiplayer Cursors Hidden";

document.getElementById("myPopup").style.display = "block";

	document.getElementById("check6").style.display = "none";
	document.getElementById("cursor").style.marginTop = "0px";
	
}
}

function loginForm()
{
	document.getElementById("Login_Popup").style.display = "block";
}


